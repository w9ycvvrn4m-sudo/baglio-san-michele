# Al-Munya — messa online

## Dove va

```
borgoideale.com/al-munya/          ← qui, accanto a al-uns/, mai dentro
```

Struttura, identica a quella del riad:

```
al-munya/index.html                 pagina pubblica (FR)
al-munya/en/index.html              pagina pubblica (EN)
al-munya/espace-a7f3c9e2.html       area riservata (FR)
al-munya/en/espace-a7f3c9e2.html    area riservata (EN)
al-munya/.htaccess                  protezione con password, da attivare
```

Le immagini stanno in `borgoideale.com/assets/` come per il riad: `../assets/`
dalla radice, `../../assets/` da `en/`. Nessuna cartella immagini propria.

| file in assets/ | uso |
|---|---|
| `logo-munya-sito.png` | emblema sopra il titolo, pagine pubbliche |
| `logo-nudama-sito.png` | emblema sopra il titolo, area riservata |
| `favicon-munya.ico` · `apple-touch-icon-munya.png` | pagine pubbliche |
| `favicon-nudama.ico` · `apple-touch-icon-nudama.png` | area riservata |

## Nessun robots.txt

Non ne trovi uno in questa cartella, ed è voluto: `robots.txt` vale per l'intero
dominio e sta nella radice di borgoideale.com — metterne uno qui non farebbe
nulla, e modificare quello del dominio per nominare `/al-munya/` **rivelerebbe
il percorso**, perché robots.txt è pubblico. L'esclusione dai motori è affidata
al `noindex, nofollow, noarchive` presente in ogni pagina.

## L'area riservata

Nome con token: `espace-a7f3c9e2.html`. Nessun link vi punta dalla pagina
pubblica: ci si arriva solo conoscendo l'indirizzo. Il token si comunica ai soci
una volta sola.

Per la password, tre strade: `.htaccess` (già pronto, genera il `.htpasswd`
fuori dalla cartella pubblica), la protezione integrata di Netlify, oppure
**Cloudflare Access** — che è quello che consiglierei: con l'accesso per email
radiare un socio è togliere una riga, mentre una password condivisa fra
novantanove uomini non è una password e non si può revocare a uno solo.

## Nessun link dal riad

Il sito del riad non rimanda qui, e non deve. Il collegamento fra le due case è
la cooptazione, non un menù. Vedi §13 della nota di concetto e §11 del documento
di riferimento.

## Da fare prima di pubblicare

- [ ] decidere il dominio definitivo (§13) — allora cambiano i `canonical`
- [ ] attivare la protezione dell'area riservata
- [ ] sottoporre al faqīh il ḥadīth *al-majālis bi-l-amāna* e la formula *cento meno uno*
- [ ] le fotografie degli hero, quando ci saranno (brief-photographies.md)
